============================================================
                 END USER LICENCE AGREEMENT
============================================================

>>>>>>>>>>>>>>>>>>>>>>>>> WARNING <<<<<<<<<<<<<<<<<<<<<<<<<<

  NO REUPLOADS. NO REUPLOADS. NO REUPLOADS. NO REUPLOADS.
  NO REUPLOADS. NO REUPLOADS. NO REUPLOADS. NO REUPLOADS.
  NO REUPLOADS. NO REUPLOADS. NO REUPLOADS. NO REUPLOADS.
  NO REUPLOADS. NO REUPLOADS. NO REUPLOADS. NO REUPLOADS.
  NO REUPLOADS. NO REUPLOADS. NO REUPLOADS. NO REUPLOADS.
  NO REUPLOADS. NO REUPLOADS. NO REUPLOADS. NO REUPLOADS.
  NO REUPLOADS. NO REUPLOADS. NO REUPLOADS. NO REUPLOADS.
  NO REUPLOADS. NO REUPLOADS. NO REUPLOADS. NO REUPLOADS.
  NO REUPLOADS. NO REUPLOADS. NO REUPLOADS. NO REUPLOADS.
  NO REUPLOADS. NO REUPLOADS. NO REUPLOADS. NO REUPLOADS.
  NO REUPLOADS. NO REUPLOADS. NO REUPLOADS. NO REUPLOADS.
  NO REUPLOADS. NO REUPLOADS. NO REUPLOADS. NO REUPLOADS.
  NO REUPLOADS. NO REUPLOADS. NO REUPLOADS. NO REUPLOADS.
  NO REUPLOADS. NO REUPLOADS. NO REUPLOADS. NO REUPLOADS.
  NO REUPLOADS. NO REUPLOADS. NO REUPLOADS. NO REUPLOADS.
  NO REUPLOADS. NO REUPLOADS. NO REUPLOADS. NO REUPLOADS.
  NO REUPLOADS. NO REUPLOADS. NO REUPLOADS. NO REUPLOADS.
  NO REUPLOADS. NO REUPLOADS. NO REUPLOADS. NO REUPLOADS.
  NO REUPLOADS. NO REUPLOADS. NO REUPLOADS. NO REUPLOADS.
  NO REUPLOADS. NO REUPLOADS. NO REUPLOADS. NO REUPLOADS.

UkiyoMoji Fonts is getting quite fed up with users who do
not respect the licence.

Read through this license if you wish to use this font.
It's the least you can do.

Using this font does NOT entitle you to reupload the font.

If you keep reuploading my fonts, I will take down EVERY
SINGLE FONT that I have ever made.

vvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvv
vvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvv
>>>>>>>>>>>>>>>>>>>>>>> ONCE AGAIN <<<<<<<<<<<<<<<<<<<<<<<<<

If you are from any of the following, you are not allowed to download this font.

* all-free-download.com
* ffonts.net
* font.downloadatoz.com
* fontarsiv.com
* fontmeme.com
* fontriver.com
* fonts101.com
* fonts2k.com
* fonts2u.com
* fontseeker.com
* fontsov.com
* fontsup.com
* freefontsdownload.net
* freefontspro.com
* lapierdo.blogspot.com
* libfreefonts.com
* myfontfree.com
* netfontes.com.br
* tattoofontsfree.com
* tutpost.com
* youfont.net

If you downloaded this from any of the following, you are not allowed to use this font. Please report any other illegitimate source and get them taken down.

  NO REUPLOADS. NO REUPLOADS. NO REUPLOADS. NO REUPLOADS.
  NO REUPLOADS. NO REUPLOADS. NO REUPLOADS. NO REUPLOADS.
  NO REUPLOADS. NO REUPLOADS. NO REUPLOADS. NO REUPLOADS.
  NO REUPLOADS. NO REUPLOADS. NO REUPLOADS. NO REUPLOADS.
  NO REUPLOADS. NO REUPLOADS. NO REUPLOADS. NO REUPLOADS.
  NO REUPLOADS. NO REUPLOADS. NO REUPLOADS. NO REUPLOADS.
  NO REUPLOADS. NO REUPLOADS. NO REUPLOADS. NO REUPLOADS.
  NO REUPLOADS. NO REUPLOADS. NO REUPLOADS. NO REUPLOADS.
  NO REUPLOADS. NO REUPLOADS. NO REUPLOADS. NO REUPLOADS.
  NO REUPLOADS. NO REUPLOADS. NO REUPLOADS. NO REUPLOADS.
  NO REUPLOADS. NO REUPLOADS. NO REUPLOADS. NO REUPLOADS.
  NO REUPLOADS. NO REUPLOADS. NO REUPLOADS. NO REUPLOADS.
  NO REUPLOADS. NO REUPLOADS. NO REUPLOADS. NO REUPLOADS.
  NO REUPLOADS. NO REUPLOADS. NO REUPLOADS. NO REUPLOADS.
  NO REUPLOADS. NO REUPLOADS. NO REUPLOADS. NO REUPLOADS.
  NO REUPLOADS. NO REUPLOADS. NO REUPLOADS. NO REUPLOADS.
  NO REUPLOADS. NO REUPLOADS. NO REUPLOADS. NO REUPLOADS.
  NO REUPLOADS. NO REUPLOADS. NO REUPLOADS. NO REUPLOADS.
  NO REUPLOADS. NO REUPLOADS. NO REUPLOADS. NO REUPLOADS.
  NO REUPLOADS. NO REUPLOADS. NO REUPLOADS. NO REUPLOADS.
  NO REUPLOADS. NO REUPLOADS. NO REUPLOADS. NO REUPLOADS.
  NO REUPLOADS. NO REUPLOADS. NO REUPLOADS. NO REUPLOADS.
  NO REUPLOADS. NO REUPLOADS. NO REUPLOADS. NO REUPLOADS.
  NO REUPLOADS. NO REUPLOADS. NO REUPLOADS. NO REUPLOADS.
  NO REUPLOADS. NO REUPLOADS. NO REUPLOADS. NO REUPLOADS.

^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^

== Terms ==
"we" or "us": UkiyoMoji Fonts, which is currently just
made up of one person, who can be contacted through
thefizzynator@gmail.com.

"you": The user who will be using the font for any
purpose, such as installing onto a device, publishing it
onto any platform, online or offline, commercial or
noncommercial.

"font": The OpenType font files included in the download,
as well as the collective design of the letters.

"group": A company or noncommercial grapical team working
together on a free or commercial project. The number of
maximum concurrent users should be no more than 10.

"password": ISolemnlySwearIGotThisFromHaley

"legitimate source": A service where the font is directly
uploaded by the author, and available for download. Dafont
is a legitimate source of choice for UkiyoMoji fonts at
the time of writing. Any other service, except Creative
Market, is likely an illegitimate source.

"illegitimate source": A service where the font is
directly uploaded by anyone other than the author or a
trusted third party, and available for download.

"reupload": To host any easily downloadable version of the
font, with the intent or effect that others may download
the font file onto their own device, with or without this
licence agreement.

== Commercial Use ==
The commercial use of the font is allowed only for a user,
individual or a member of a group, who 1) downloaded the
font from a legitimate source, 2) has express permission
from UkiyoMoji for said commercial use, and 3) has
declared in good faith that the use does not violate the
use guidelines. If this font is downloaded from an
illegitimate source, any use of the font is not allowed.
A member of a group may only "take home" font data for use
within the group's projects. Any commercial use outside
the project is not allowed.

When possible, the font should be credited; this should
include the name of the font and its designer/foundry
"UkiyoMoji Fonts".

== Personal use ==
You are allowed to use Quinone in any personal use
according to the guidelines. Here, personal use is any use
where you are not making a profit.

== Use guidelines ==
You are disallowed to use Quinone for any illicit,
violent, or pornographic purposes. These include, for
example, usage for sites facilitating piracy; logotype for
weapons and artillery, whether physical or strictly
digital; and for title cards of pornographic videos and
images.
You MAY NOT reupload individual weights or the full font
package in public; you are, however, allowed to upload the
font into a cloud storage service as unlisted, given that
only members of the group may access and download the font.

== Desktop and Print ==
You may install this font onto up to 3 computers per
person, or the aforementioned limit for groups. However,
if you no longer use one of the computers, you may
subtract that computer from the total, as long as either
the font is uninstalled from it or the computer is not
functional.

== Embedding ==
You may embed static graphic images of the font into any
electronic document, as long as they are not used as a
replacement for the font (e.g. a set of images that
showcase each letter of the alphabet, to which a program
refers back to display a string of text). However, even if
they are, as long as the text is processed enough (e.g.
drop shadow, glow, gradient or pattern fill, gradient or
pattern stroke) so that backwards-engineering is rendered
difficult or impractical, such images are allowed to be
embedded.

You may embed copies of the font into a digital program,
as long as it is distributed in a secure format where
extraction of the font is difficult, and the digital
program does not generate documents that also have a copy
of the font embedded.

== Web fonts ==
You may embed copies of the font into a Web page, as long
as said Web page is not involved in illicit or
pornographic activity.

vvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvv
vvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvvv
>>>>>>>>>>>>>>>>>>>>>> ONE FINAL TIME <<<<<<<<<<<<<<<<<<<<<<

  NO REUPLOADS. NO REUPLOADS. NO REUPLOADS. NO REUPLOADS.
  NO REUPLOADS. NO REUPLOADS. NO REUPLOADS. NO REUPLOADS.
  NO REUPLOADS. NO REUPLOADS. NO REUPLOADS. NO REUPLOADS.
  NO REUPLOADS. NO REUPLOADS. NO REUPLOADS. NO REUPLOADS.
  NO REUPLOADS. NO REUPLOADS. NO REUPLOADS. NO REUPLOADS.
  NO REUPLOADS. NO REUPLOADS. NO REUPLOADS. NO REUPLOADS.
  NO REUPLOADS. NO REUPLOADS. NO REUPLOADS. NO REUPLOADS.
  NO REUPLOADS. NO REUPLOADS. NO REUPLOADS. NO REUPLOADS.
  NO REUPLOADS. NO REUPLOADS. NO REUPLOADS. NO REUPLOADS.
  NO REUPLOADS. NO REUPLOADS. NO REUPLOADS. NO REUPLOADS.
  NO REUPLOADS. NO REUPLOADS. NO REUPLOADS. NO REUPLOADS.
  NO REUPLOADS. NO REUPLOADS. NO REUPLOADS. NO REUPLOADS.
  NO REUPLOADS. NO REUPLOADS. NO REUPLOADS. NO REUPLOADS.
  NO REUPLOADS. NO REUPLOADS. NO REUPLOADS. NO REUPLOADS.
  NO REUPLOADS. NO REUPLOADS. NO REUPLOADS. NO REUPLOADS.
  NO REUPLOADS. NO REUPLOADS. NO REUPLOADS. NO REUPLOADS.
  NO REUPLOADS. NO REUPLOADS. NO REUPLOADS. NO REUPLOADS.
  NO REUPLOADS. NO REUPLOADS. NO REUPLOADS. NO REUPLOADS.
  NO REUPLOADS. NO REUPLOADS. NO REUPLOADS. NO REUPLOADS.
  NO REUPLOADS. NO REUPLOADS. NO REUPLOADS. NO REUPLOADS.
  NO REUPLOADS. NO REUPLOADS. NO REUPLOADS. NO REUPLOADS.
  NO REUPLOADS. NO REUPLOADS. NO REUPLOADS. NO REUPLOADS.
  NO REUPLOADS. NO REUPLOADS. NO REUPLOADS. NO REUPLOADS.
  NO REUPLOADS. NO REUPLOADS. NO REUPLOADS. NO REUPLOADS.
  NO REUPLOADS. NO REUPLOADS. NO REUPLOADS. NO REUPLOADS.
  NO REUPLOADS. NO REUPLOADS. NO REUPLOADS. NO REUPLOADS.
  NO REUPLOADS. NO REUPLOADS. NO REUPLOADS. NO REUPLOADS.
  NO REUPLOADS. NO REUPLOADS. NO REUPLOADS. NO REUPLOADS.
  NO REUPLOADS. NO REUPLOADS. NO REUPLOADS. NO REUPLOADS.
  NO REUPLOADS. NO REUPLOADS. NO REUPLOADS. NO REUPLOADS.
  NO REUPLOADS. NO REUPLOADS. NO REUPLOADS. NO REUPLOADS.
  NO REUPLOADS. NO REUPLOADS. NO REUPLOADS. NO REUPLOADS.
  NO REUPLOADS. NO REUPLOADS. NO REUPLOADS. NO REUPLOADS.
  NO REUPLOADS. NO REUPLOADS. NO REUPLOADS. NO REUPLOADS.
  NO REUPLOADS. NO REUPLOADS. NO REUPLOADS. NO REUPLOADS.
  NO REUPLOADS. NO REUPLOADS. NO REUPLOADS. NO REUPLOADS.
  NO REUPLOADS. NO REUPLOADS. NO REUPLOADS. NO REUPLOADS.
  NO REUPLOADS. NO REUPLOADS. NO REUPLOADS. NO REUPLOADS.
  NO REUPLOADS. NO REUPLOADS. NO REUPLOADS. NO REUPLOADS.
  NO REUPLOADS. NO REUPLOADS. NO REUPLOADS. NO REUPLOADS.
  NO REUPLOADS. NO REUPLOADS. NO REUPLOADS. NO REUPLOADS.
  NO REUPLOADS. NO REUPLOADS. NO REUPLOADS. NO REUPLOADS.
  NO REUPLOADS. NO REUPLOADS. NO REUPLOADS. NO REUPLOADS.
  NO REUPLOADS. NO REUPLOADS. NO REUPLOADS. NO REUPLOADS.
  NO REUPLOADS. NO REUPLOADS. NO REUPLOADS. NO REUPLOADS.
  NO REUPLOADS. NO REUPLOADS. NO REUPLOADS. NO REUPLOADS.
  NO REUPLOADS. NO REUPLOADS. NO REUPLOADS. NO REUPLOADS.
  NO REUPLOADS. NO REUPLOADS. NO REUPLOADS. NO REUPLOADS.
  NO REUPLOADS. NO REUPLOADS. NO REUPLOADS. NO REUPLOADS.
  NO REUPLOADS. NO REUPLOADS. NO REUPLOADS. NO REUPLOADS.
  NO REUPLOADS. NO REUPLOADS. NO REUPLOADS. NO REUPLOADS.
  NO REUPLOADS. NO REUPLOADS. NO REUPLOADS. NO REUPLOADS.
  NO REUPLOADS. NO REUPLOADS. NO REUPLOADS. NO REUPLOADS.
  NO REUPLOADS. NO REUPLOADS. NO REUPLOADS. NO REUPLOADS.
  NO REUPLOADS. NO REUPLOADS. NO REUPLOADS. NO REUPLOADS.
  NO REUPLOADS. NO REUPLOADS. NO REUPLOADS. NO REUPLOADS.
  NO REUPLOADS. NO REUPLOADS. NO REUPLOADS. NO REUPLOADS.
  NO REUPLOADS. NO REUPLOADS. NO REUPLOADS. NO REUPLOADS.
  NO REUPLOADS. NO REUPLOADS. NO REUPLOADS. NO REUPLOADS.
  NO REUPLOADS. NO REUPLOADS. NO REUPLOADS. NO REUPLOADS.

               THANK YOU FOR NOT REUPLOADING.

^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^